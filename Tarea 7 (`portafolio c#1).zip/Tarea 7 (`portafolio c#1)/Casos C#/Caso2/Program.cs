﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Caso2
{
   

    class Program
    {
        static void Main(string[] args)
        {
            // Solicitar el salario base mensual
            Console.Write("Ingrese el salario base mensual: ");
            double salarioBase = double.Parse (Console.ReadLine());

            // Solicitar el monto de ventas mensuales
            Console.Write("Ingrese el monto de ventas mensuales: ");
            double ventasMensuales = double.Parse (Console.ReadLine());
            //double.Parse se asegura de que los datos ingresados sean válidos
            // Calcular la comisión (10% de las ventas mensuales)
            double comision = ventasMensuales * 0.1;

            // Calcular el salario bruto (salario base + comisión)
            double salarioBruto = salarioBase + comision;

            // Mostrar el salario bruto del empleado
            Console.WriteLine("El salario bruto del empleado es: " + salarioBruto);

            // Esperar a que el usuario presione una tecla para salir
            Console.ReadKey();
        }
    }

}
