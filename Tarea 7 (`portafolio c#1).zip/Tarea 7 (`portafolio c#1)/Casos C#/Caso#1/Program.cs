﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


//Realice un programa en C# para determinar el área en metros cuadrados de un
//terreno rectangular cuyo frente y fondo se dan en pies.
//Solicite los datos de frente y fondo, el sistema debe mostrar el área en m2.

namespace Caso1
{
    class Program
    {
        static void Main(string[] args)
        {
            // Solicitar los datos de frente y fondo al usuario
            Console.WriteLine("Ingrese el frente del terreno en pies:");
            double frente = Double.Parse(Console.ReadLine());

            Console.WriteLine("Ingrese el fondo del terreno en pies:");
            double fondo = Double.Parse(Console.ReadLine());

            // Calcular el área en metros cuadrados
            double area = CalcularAreaTerreno(frente, fondo);

            // Mostrar el resultado al usuario
            Console.WriteLine("El área del terreno es: " + area + " metros cuadrados");
            Console.ReadKey();
        }

        // Método para calcular el área del terreno
        static double CalcularAreaTerreno(double frente, double fondo)
        {
            // Convertir los pies a metros
            double frenteEnMetros = frente * 0.3048;
            double fondoEnMetros = fondo * 0.3048;

            // Calcular el área en metros cuadrados
            double area = frenteEnMetros * fondoEnMetros;

            return area;



        }
    }
}
