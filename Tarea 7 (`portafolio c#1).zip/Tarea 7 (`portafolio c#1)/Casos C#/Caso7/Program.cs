﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Se tiene un terreno rectangular cuyas dimensiones de largo y ancho
//están en relación 2 a 1. Solicite el ancho del terreno al usuario.
//a.Para cercar con malla este terreno se colocan postes a lo largo del perímetro
//a una distancia de 2 m uno del otro. ¿Cuántos postes son necesarios para cercar el terreno?
namespace Caso7
{
    internal class Program
    {
        static void Main(string[] args)
        {
           

            {
                Console.WriteLine("Ingrese el ancho del terreno en metros:");
                double ancho = Double.Parse(Console.ReadLine());
                //double.Parse para convertir las cadenas de entrada a valores numéricos de tipo double
                double largo = ancho * 2; //si se parte de las dimensiones 2 a 1 se deduce que el largo es el doble que el ancho
                double perimetro = (largo * 2) + (ancho * 2);
                int cantidadPostes = (int)(perimetro / 2); //(int) conversión explícita de double a int

                Console.WriteLine("La cantidad de postes necesarios para cercar el terreno es: " + cantidadPostes);
                Console.ReadKey();
            }
        }

    }
}

