﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Caso3
{

    class Program
    {
        static void Main(string[] args)
        {
            // Solicitar la cantidad de horas
            Console.Write("Ingrese la cantidad de horas: ");
            int horas = int.Parse(Console.ReadLine());

            // Solicitar la cantidad de minutos
            Console.Write("Ingrese la cantidad de minutos: ");
            int minutos = int.Parse(Console.ReadLine());

            // Solicitar la cantidad de segundos
            Console.Write("Ingrese la cantidad de segundos: ");
            int segundos = int.Parse(Console.ReadLine());

            // Calcular el total de segundos
            int totalSegundos = (horas * 3600) + (minutos * 60) + segundos;

            // Mostrar el resultado
            Console.WriteLine("El total de segundos es: " + totalSegundos);

            // Esperar a que el usuario presione una tecla para salir
            Console.ReadKey();
        }
    }

}
