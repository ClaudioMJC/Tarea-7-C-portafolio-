﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Caso5
{

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingrese una cantidad de MB:");
            double megabytes = Convert.ToDouble(Console.ReadLine());

            double bits = megabytes * 8 * 1024 * 1024; //se calcula el valor de megabytes para cada caso
            double bytes = megabytes * 1024 * 1024;
            double kilobytes = megabytes * 1024;
            double gigabytes = megabytes / 1024;

            Console.WriteLine($"Equivalente en bits: {bits}");
            Console.WriteLine($"Equivalente en bytes: {bytes}");
            Console.WriteLine($"Equivalente en kilobytes: {kilobytes}");
            Console.WriteLine($"Equivalente en gigabytes: {gigabytes}");
            Console.ReadKey();
        }
    }

}
