﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Caso6
{
    class Program
    {
        static void Main(string[] args)
        {
            double[] salarios = { 400000, 420000, 410000, 450000, 410000, 440000, 400000, 460000, 420000, 430000, 440000, 490000 };
            double salarioAcumulado = salarios.Sum();  // Sumamos los salarios mensuales para obtener el salario acumulado del año
            double aguinaldo = salarioAcumulado / 12;  // Dividimos el salario acumulado entre 12 para obtener el aguinaldo

            Console.WriteLine($"El monto de aguinaldo correspondiente es: {aguinaldo}");
            Console.ReadKey();
        }
    }
}
