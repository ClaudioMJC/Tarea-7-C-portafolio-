﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Caso4
{

    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Ingrese la cantidad de segundos: ");
            int segundos = int.Parse(Console.ReadLine());

            int horas = segundos / 3600;
            segundos %= 3600;
            //% módulo determina los segundos sobrantes de la división una vez obtenido las horas 
            int minutos = segundos / 60;
            segundos %= 60;
            // De igual forma se actualizan los segundos restantes una vez obtenidos los segundos
            Console.WriteLine($"Horas: {horas}");
            Console.WriteLine($"Minutos: {minutos}");
            Console.WriteLine($"Segundos: {segundos}");
            Console.ReadKey();
        }
    }

}
